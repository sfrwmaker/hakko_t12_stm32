#ifndef _U8G_ARM_H
#define _U8G_ARM_H

#define U8G_STM32_HAL_SPI

#include "stm32f1xx_hal.h"
#include "u8g.h"

#define		SPI_HANDLER hspi2 // use your SPI handler
extern 		SPI_HandleTypeDef SPI_HANDLER;

#define 	CS		OLED_CS_Pin
#define		DC		OLED_DC_Pin
#define     RST		OLED_RESET_Pin
#define 	PORT GPIOB

uint8_t u8g_com_hw_spi_fn(u8g_t *u8g, uint8_t msg, uint8_t arg_val, void *arg_ptr);

#endif
